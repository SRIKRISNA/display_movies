import './App.css';
import Main from './movies/Main';

function App() {
  return (
    <div className="App">
      <Main/>
    </div>
  );
}

export default App;
